# react-consume-api
Consume API with React. Use of Hooks and Context. CRUD with tables and forms in PrimeFaces. Fast and easy !!

Video tutorial: https://www.youtube.com/watch?v=sxylafSufqc
